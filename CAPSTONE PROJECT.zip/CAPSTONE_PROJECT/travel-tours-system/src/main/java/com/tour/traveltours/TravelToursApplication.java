package com.tour.traveltours;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelToursApplication {

    public static void main(String[] args) {
        SpringApplication.run(TravelToursApplication.class, args);
    }
}
